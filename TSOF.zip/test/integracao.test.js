import app from '../src/app.js';
import request from 'supertest';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { clearDatabase } from './utils/clearDatabase.js';
import { MontadoraFactory } from './factories/MontadoraFactory.js';
// import { ClienteFactory } from './factories/ClienteFactory.js';
// import { VeiculoFactory } from './factories/VeiculoFactory.js';

describe ('API de montadoras', () => {
    beforeEach(async () => {
        await MontadoraFactory.createMontadora('Toyota', 'Japão');
    
        vi.clearAllMocks();
    });

    afterEach(async () => {
        await clearDatabase();

        vi.resetAllMocks();
    })
    
    it("deve criar uma montadora com sucesso.", async () => {
        const response = await request(app)
        .post('/montadoras')
        .send({nome: 'Hyundai', pais: 'Coreia do Sul'});

        expect(response.status).toBe(201);
        expect(response.body.data).toHaveProperty('insertId');
    });
});
